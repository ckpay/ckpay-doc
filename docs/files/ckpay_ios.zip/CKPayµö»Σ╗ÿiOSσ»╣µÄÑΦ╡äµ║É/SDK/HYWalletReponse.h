//
//  HYWalletReponse.h
//  HYWalletSdk
//
//  Created by 降瑞雪 on 2017/11/15.
//  Copyright © 2017年 汇元网. All rights reserved.
/*
    SDK响应类，
 
    字段有
 */

//支付、认证同步回调的结果状态码。
 enum  HYWalletResultCode {
     
     HYWalletSuccess     = 1,
     HYWalletFailure     = 0,
     HYWalletError       = -1,
     HYWalletCancel      = -2,
     HYWalletUnkonw      = -3
} ;

#import <Foundation/Foundation.h>

@interface HYWalletReponse : NSObject

@property (nonatomic,assign) NSInteger code; //状态码。
@property (nonatomic,copy) NSString * message; //对应的描述
@property (nonatomic,copy) NSDictionary * detailInfos; //只有成功时，此字段才有值。

@end
