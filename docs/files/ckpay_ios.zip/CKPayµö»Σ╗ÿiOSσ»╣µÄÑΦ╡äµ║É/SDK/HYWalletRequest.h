//
//  HYWalletRequest.h
//  HYWalletSdk
//
//  Created by 降瑞雪 on 2017/11/15.
//  Copyright © 2017年 汇元网. All rights reserved.
/*
    发起支付 入参相关类。具体入参待定。
 */

#import <Foundation/Foundation.h>

@interface HYWalletRequest : NSObject

@property (nonatomic,copy) NSString *schemeStr; //商户端url scheme
@property (nonatomic,copy) NSString *hy_pay_id; // CKPAY服务器返回的预支付id .
@property (nonatomic,copy) NSString *out_trade_no; //商户平台订单号。
@end
