//
//  HYWalletSdkManager.h
//  HYWalletSdk
//
//  Created by 降瑞雪 on 2017/11/15.
//  Copyright © 2017年 汇元网. All rights reserved.
/*
    SDK主管理类。
    初步定义接口有
 
    1.注册应用方法。
    2.发起支付方法。
    3.接收应用回调方法。
 */

#import <Foundation/Foundation.h>
#import "HYWalletRequest.h"
#import "HYWalletReponse.h"


@interface HYWalletSdkManager : NSObject

//app 注册。
+(BOOL)registerApp:(NSString *)appid;

//唤起钱包app操作，附带相关参数，本次唤起钱包，可以是支付、授权登录、交易签名。
+ (void)sendReq:(HYWalletRequest *)request completion:(void(^)(HYWalletReponse *response))response;

//处理所有类型的回调结果
+ (BOOL) handleOpenURL:(NSURL *) url;

//SDK版本号。
+ (NSString *)apiVersion;

//是否汇元APP被安装。
+ (BOOL)isWalletAppInstalled;

//获取钱包APP下载地址。
+(NSString *) getWalletAppInstallUrl;

@end
