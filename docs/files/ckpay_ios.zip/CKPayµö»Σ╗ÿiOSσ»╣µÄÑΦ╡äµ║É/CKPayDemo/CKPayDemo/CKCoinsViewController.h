//
//  CKCoinsViewController.h
//  HYWalletSdk
//
//  Created by 降瑞雪 on 2019/1/28.
//  Copyright © 2019 汇元网. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

typedef void(^CKCallback)(NSDictionary *d);
@interface CKCoinsViewController : UIViewController

@property (nonatomic,copy)CKCallback block;

@end

NS_ASSUME_NONNULL_END
