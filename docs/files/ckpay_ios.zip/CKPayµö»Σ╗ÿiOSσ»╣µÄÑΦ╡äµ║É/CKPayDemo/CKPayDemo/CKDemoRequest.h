//
//  CKDemoRequest.h
//  HYWalletSdk
//
//  Created by 降瑞雪 on 2019/1/28.
//  Copyright © 2019 汇元网. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef void(^RequestBlock)(NSDictionary *param);

@interface CKDemoRequest : NSObject

@property (nonatomic,copy) NSString * coin_code;

- (void)sendRequest:(NSString *)amt callback:(RequestBlock)block;

- (void)sendRequestForGetCoinListCallback:(RequestBlock)block;
@end

NS_ASSUME_NONNULL_END
