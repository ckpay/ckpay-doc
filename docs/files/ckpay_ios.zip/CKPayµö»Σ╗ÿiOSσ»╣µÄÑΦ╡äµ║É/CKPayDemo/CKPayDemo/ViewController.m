//
//  ViewController.m
//  HYWalletSdk
//
//  Created by 降瑞雪 on 2017/11/15.
//  Copyright © 2017年 汇元网. All rights reserved.
//

#import "ViewController.h"
#import "HYWalletRequest.h"
#import "HYWalletReponse.h"
#import "HYWalletSdkManager.h"
#import "JXTAlertView.h"
#import "CKDemoRequest.h"
#import "CKCoinsViewController.h"


@interface ViewController ()<UITableViewDelegate,UITableViewDataSource>

@property (weak, nonatomic) IBOutlet UIActivityIndicatorView *actView;
@property (weak, nonatomic)  UITextField *amtTF;
@property (strong, nonatomic) IBOutlet UIView *footerView;
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (nonatomic,copy) NSString * coin_code;

@end

@implementation ViewController


- (void)openCKPay:(NSDictionary *)dic
{
    //商户iOS端对接有效代码。
    HYWalletRequest * request = [HYWalletRequest new];
    request.schemeStr = @"demo1";
    request.out_trade_no = dic[@"out_trade_no"];  //商户平台订单号。
    request.hy_pay_id = dic[@"hy_pay_id"]; //CKPAY 预支付ID，有商户服务器通过CKPAY统一下单接口获取。
    [HYWalletSdkManager sendReq:request completion:^(HYWalletReponse *response) {
        jxt_showToastTitle(response.message, 3);
        NSLog(@"response: %@",response.message);
    }];
}

- (IBAction)onClick:(UIButton *)sender {
    
    if (!self.coin_code) {
        jxt_showToastTitle(@"请选择支付币种", 2);
        return;
    }
    if (!self.amtTF.text){
        jxt_showToastTitle(@"请输入支付币量", 2);
        return;
    }
    sender.enabled = false;
    [self.actView startAnimating];
    
    //此部分代码作用仅为获取预支付ID,仅做演示使用，商户侧正常逻辑应该将获取预支付ID放在服务器实现。
    CKDemoRequest * request = [[CKDemoRequest alloc] init];
    request.coin_code = self.coin_code;
    [request sendRequest:self.amtTF.text callback:^(NSDictionary * _Nonnull param) {
        [self.actView stopAnimating];
        sender.enabled = true;
        if (!param) {
            return ;
        }
        [self openCKPay:param];
    }];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    //保证当前APP，唯一对应AppID
    _actView.hidden = true;
    _tableView.tableFooterView = _footerView;
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 2;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:[NSString stringWithFormat:@"cell%@",@(indexPath.row)] forIndexPath:indexPath];
    if (indexPath.row == 1) {
        self.amtTF = [cell.contentView viewWithTag:100];
    }
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    if (indexPath.row == 0) {
        
        CKCoinsViewController * vc = [self vcFormStoryBoard:@"Main" vcId:@"vcId"];
        vc.block = ^(NSDictionary * _Nonnull d) {
            UITableViewCell * cell = [tableView cellForRowAtIndexPath:indexPath];
            UILabel * coinCodeLabel = [cell.contentView viewWithTag:100];
            coinCodeLabel.text = d[@"coin_code"];
            self.coin_code = d[@"coin_code"];
        };
        [self.navigationController showViewController:vc sender:nil];
    }
}

-(__kindof UIViewController *)vcFormStoryBoard:(NSString *)storyBoard vcId:(NSString *)vcId{
    UIStoryboard *productStoryboard = [UIStoryboard storyboardWithName:storyBoard bundle:nil];
    return [productStoryboard instantiateViewControllerWithIdentifier:vcId];
}
@end

/*
 {
    "method":"ckpay.pay.apply",
    "version":"1.0",
    "mch_id":"100001",
    "app_id":"ckp180809001000010000305E305D256",
    "charset":"utf-8",
    "sign_type":"MD5",
    "timestamp":"20190121110603",
    "biz_content":"{\"out_trade_no\":\"20190121110603540\",\"coin_code\":\"ETH\",\"subject\":\"测试0.01个eth\",\"trade_currency\":\"0\",\"total_fee\":\"0.01\",\"over_market_rate\":\"5\",\"client_ip\":\"192.168.196.166\",\"notify_url\":\"http://local.heepay.com/Heebit/Test/Pay/RecNotifyUrl.aspx\",\"return_url\":\"http://local.heepay.com/Heebit/Test/Pay/RecReturnUrl.aspx\"}",
    "sign":"DA53EA4704C354D824D399DAB5241777"
 }
 
 
    {
 "return_code":"SUCCESS",
 "return_msg":"执行完成",
 "result_code":"SUCCESS",
 "result_msg":"下单申请成功",
 "app_id":"ckp180809001000010000305E305D256",
 "out_trade_no":"20190121110603540",
 "bill_no":"P1901211106003401403",
 "hy_pay_id":"P1v56k3a03chck",
 "subject":"测试0.01个eth",
 "bill_status":"Undeal",
 "total_fee":"0.01",
 "real_vol":"0",
 "hy_url":"http://local.heepay.com/Heebit/p/P1v56k3a03chck",
 "return_url":"http://local.heepay.com/Heebit/Test/Pay/RecReturnUrl.aspx",
 "sign":"F3E3E67C1EC97112783E52DD85C75EC2"
 
 }
 */
