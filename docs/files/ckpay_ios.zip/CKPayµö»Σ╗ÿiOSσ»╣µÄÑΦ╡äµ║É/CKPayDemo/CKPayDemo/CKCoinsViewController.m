//
//  CKCoinsViewController.m
//  HYWalletSdk
//
//  Created by 降瑞雪 on 2019/1/28.
//  Copyright © 2019 汇元网. All rights reserved.
//

#import "CKCoinsViewController.h"
#import "CKDemoRequest.h"

@interface CKCoinsViewController ()
@property (weak, nonatomic) IBOutlet UITableView *tableView;

@property (nonatomic,copy) NSArray * items;
@end

@implementation CKCoinsViewController

- (void)getCoinList
{
    CKDemoRequest * request = [[CKDemoRequest alloc] init];
    [request sendRequestForGetCoinListCallback:^(NSDictionary * _Nonnull param) {
        NSArray * item = [NSJSONSerialization JSONObjectWithData:[param[@"coin_list"] dataUsingEncoding:NSUTF8StringEncoding] options:0 error:nil];
        self.items = item;
        
        [_tableView reloadData];
        NSLog(@" %@",param);
    }];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self getCoinList];
    // Do any additional setup after loading the view.
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _items.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:@"cell" forIndexPath:indexPath];
    cell.textLabel.text = self.items[indexPath.row][@"coin_code"];
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    if (self.block) {
        self.block(self.items[indexPath.row]);
    }
    [self.navigationController popViewControllerAnimated:YES];
}
@end
