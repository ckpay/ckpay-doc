//
//  CKDemoRequest.m
//  HYWalletSdk
//
//  Created by 降瑞雪 on 2019/1/28.
//  Copyright © 2019 汇元网. All rights reserved.
//

#import "CKDemoRequest.h"
#import <CommonCrypto/CommonDigest.h>
#import "JXTAlertView.h"
#import "AFNetworking.h"
@interface CKDemoRequest()
@property (nonatomic,copy) NSString *timeStamp;
@property (nonatomic,copy) NSString *out_trade_no;
@property (nonatomic,copy) NSString *amt;

@property (nonatomic,copy) RequestBlock block;
@end


static NSString * kBaseUrl_Pay = @"https://local.heepay.com/Heebit/api/v1/PayApply";
static NSString * kBaseUrl_GetCoinList = @"https://local.heepay.com/Heebit/api/v1/coinlist";

static NSString * kMerchId = @"100001";
static NSString * kMd5Key = @"73DB82FC47F842F8B4E1E633";
static NSString * kAppId = @"ckp180809001000010000305E305D256";


@implementation CKDemoRequest

-(NSString *) md5:(NSString *)str
{
    const char *cStr = [str UTF8String];
    unsigned char digest[CC_MD5_DIGEST_LENGTH];
    CC_MD5( cStr, (unsigned int)strlen(cStr), digest );
    
    NSMutableString *output = [NSMutableString stringWithCapacity:CC_MD5_DIGEST_LENGTH * 2];
    
    for(int i = 0; i < CC_MD5_DIGEST_LENGTH; i++)
        [output appendFormat:@"%02X", digest[i]];
    
    return output;
}

//调用统一下单接口。
-(NSString *)getSystemTimeString
{
    NSDate * data = [NSDate date];
    NSDateFormatter * formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:@"yyyyMMddHHmmss"];
    NSString * timeString = [formatter stringFromDate:data];
    return timeString;
}

- (NSDictionary *)getRequestParam
{
    NSDictionary * dic = @{
                           @"method":@"ckpay.pay.apply",
                           @"version":@"1.0",
                           @"mch_id": kMerchId,
                           @"app_id":kAppId,
                           @"charset":@"utf-8",
                           @"sign_type":@"MD5",
                           @"timestamp":self.timeStamp,
                           @"biz_content":[NSString stringWithFormat:@"{\"out_trade_no\":\"%@\",\"coin_code\":\"%@\",\"subject\":\"测试0.01个eth\",\"trade_currency\":\"0\",\"total_fee\":\"%@\",\"over_market_rate\":\"5\",\"client_ip\":\"192.168.196.166\",\"notify_url\":\"http://local.heepay.com/Heebit/Test/Pay/RecNotifyUrl.aspx\",\"return_url\":\"http://local.heepay.com/Heebit/Test/Pay/RecReturnUrl.aspx\"}",self.out_trade_no,self.coin_code,self.amt],
                           };
    return dic;
}

- (NSString *)sign:(NSDictionary *)dic
{
    NSMutableArray * tmp = [NSMutableArray arrayWithArray:dic.allKeys];
    [tmp sortUsingComparator:^NSComparisonResult(id  _Nonnull obj1, id  _Nonnull obj2) {
        return [obj1 compare:obj2];
    }];
    
    NSMutableString * string = [[NSMutableString alloc] init];
    for (NSString * key in tmp) {
        
        NSString * value = dic[key];
        [string appendString:[NSString stringWithFormat:@"%@=%@&",key,value]];
    }
    
    [string appendString:[NSString stringWithFormat:@"key=%@",kMd5Key]];
    NSString * md5 = [self md5:string];
    return md5;
}

- (void)sendRequest:(NSString *)amt callback:(RequestBlock)block
{
    
    self.amt = amt;
    self.out_trade_no = [self getSystemTimeString];
    self.timeStamp = [self getSystemTimeString];
    self.block = block;
    NSMutableDictionary * dic = [NSMutableDictionary dictionaryWithDictionary:[self getRequestParam]];
    dic[@"sign"] = [self sign:dic];
    [self afnPost:dic requestURL:kBaseUrl_Pay];
}

- (void)sendRequestForGetCoinListCallback:(RequestBlock)block
{
    self.out_trade_no = [self getSystemTimeString];
    self.timeStamp = [self getSystemTimeString];
    self.block = block;
    
    NSDictionary * dic0 = @{
                           @"method":@"ckpay.coin.list",
                           @"version":@"1.0",
                           @"app_id":kAppId,
                           @"mch_id":kMerchId,
                           @"charset":@"UTF-8",
                           @"timestamp":self.timeStamp,
                           @"biz_content":@"{\"is_open_coin_list\":\"1\"}",
                           @"sign_type":@"md5"
                           };
    
    NSMutableDictionary * dic1 = [NSMutableDictionary dictionaryWithDictionary:dic0];
    dic1[@"sign"] = [self sign:dic1];
   [self afnPost:dic1 requestURL:kBaseUrl_GetCoinList];
}

- (void)afnPost:(NSDictionary *)parameters
     requestURL:(NSString *)url
{
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    manager.requestSerializer.timeoutInterval = 15.0f;
    ((AFJSONResponseSerializer *)manager.responseSerializer).removesKeysWithNullValues = YES;
    manager.responseSerializer.acceptableContentTypes = [NSSet setWithObjects:@"application/json", @"text/html",@"text/json", @"text/javascript", @"text/plain", nil];
    [UIApplication sharedApplication].networkActivityIndicatorVisible = YES;
    // request Json 序列化
    NSLog(@"请求地址: %@",url);
    NSLog(@"入参: %@",parameters);
    manager.requestSerializer=[AFJSONRequestSerializer serializer];
    [manager POST:url parameters:parameters progress:^(NSProgress * _Nonnull uploadProgress) {
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        [UIApplication sharedApplication].networkActivityIndicatorVisible = false;
        NSLog(@"\n返回参数: %@\n",responseObject);
        
        NSMutableDictionary * dic = [NSMutableDictionary dictionaryWithDictionary:responseObject];
        dic[@"out_trade_no"] = self.out_trade_no;
        
       
        if ([dic[@"return_code"] isEqualToString:@"SUCCESS"]){
            if (self.block){
                self.block(dic);
            }
        }
        else {
           
            if (self.block){
                self.block(nil);
            }jxt_showToastTitle(responseObject[@"return_msg"], 2);
        }
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        jxt_showToastTitle(error.localizedDescription, 2);
        if (self.block){
            self.block(nil);
        }
        [UIApplication sharedApplication].networkActivityIndicatorVisible = false;
    }];
}

@end
