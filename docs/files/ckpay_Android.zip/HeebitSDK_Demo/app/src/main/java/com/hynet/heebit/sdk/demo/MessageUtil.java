package com.hynet.heebit.sdk.demo;

import android.os.Bundle;
import android.os.Message;

public class MessageUtil {

    private static MessageUtil messageUtil;

    private MessageUtil() {
        // cannot be instantiated
    }

    public static synchronized MessageUtil getInstance() {
        if (messageUtil == null) {
            messageUtil = new MessageUtil();
        }
        return messageUtil;
    }

    public static void releaseInstance() {
        if (messageUtil != null) {
            messageUtil = null;
        }
    }

    public Message getMessage(int state) {
        Message message = Message.obtain();
        message.what = state;
        return message;
    }

    public Message getMessage(int state, Bundle bundle) {
        Message message = Message.obtain();
        message.setData(bundle);
        message.what = state;
        return message;
    }

    public Message getMessage(int state, Object obj) {
        Message message = Message.obtain();
        message.obj = obj;
        message.what = state;
        return message;
    }

    public Message getMessage(int state, String parameter) {
        Message message = Message.obtain();
        message.what = state;
        message.obj = parameter;
        return message;
    }


    public Message getErrorMessage(int state, Exception e, String error) {
        Message message = Message.obtain();
        message.what = state;
        if (e.getMessage() != null) {
            message.obj = e.getMessage();
        } else {
            message.obj = error;
        }
        return message;
    }
}
