package com.hynet.heebit.sdk.demo;

import com.alibaba.fastjson.annotation.JSONField;

public class CoinInfo {

    @JSONField(name="coin_id")
    private String coin_id;
    @JSONField(name="coin_code")
    private String coin_code;
    @JSONField(name="coin_name")
    private String coin_name;
    @JSONField(name="coin_icon_url")
    private String coin_icon_url;

    public String getCoin_id() {
        return coin_id;
    }

    public String getCoin_code() {
        return coin_code;
    }

    public String getCoin_name() {
        return coin_name;
    }

    public String getCoin_icon_url() {
        return coin_icon_url;
    }

    public void setCoin_id(String coin_id) {
        this.coin_id = coin_id;
    }

    public void setCoin_code(String coin_code) {
        this.coin_code = coin_code;
    }

    public void setCoin_name(String coin_name) {
        this.coin_name = coin_name;
    }

    public void setCoin_icon_url(String coin_icon_url) {
        this.coin_icon_url = coin_icon_url;
    }
}
