package com.hynet.heebit.sdk.demo;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.alibaba.fastjson.JSONObject;
import com.hynet.heebit.sdk.api.HeebitApi;
import com.hynet.heebit.sdk.constant.Constant;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.UUID;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private TextView tvCoinType;
    private EditText etAmount;

    private String app_id = "ckp180809001000010000305E305D256";
    private String subject = "Nexus Pixel";
    private String trade_currency = "0";
    private String over_market_rate = "5";
    private String client_ip = "127.0.0.1";
    private String notify_url = "http://local.heepay.com/Heebit/Test/Pay/RecNotifyUrl.aspx";
    private String return_url = "http://local.heepay.com/Heebit/Test/Pay/RecReturnUrl.aspx";
    private String charset = "utf-8";
    private String mch_id = "100001";
    private String method = "ckpay.pay.apply";
    private String sign_type = "MD5";
    private String version = "1.0";
    private String timestamp = new SimpleDateFormat("yyyyMMddHHmmss", Locale.getDefault()).format(new Date(System.currentTimeMillis()));
    private String key = "73DB82FC47F842F8B4E1E633";

    private static final int REQUEST_SUCCESS = 0x0001;
    private static final int REQUEST_FAIL = 0x0002;
    private static final int REQUEST_ERROR = 0x0003;

    @SuppressLint("HandlerLeak")
    private Handler handler = new Handler() {

        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            switch (msg.what) {
                case REQUEST_SUCCESS:
                    Log.d("请求成功", msg.obj.toString());
                    JSONObject jsonObject = JSONObject.parseObject(msg.obj.toString());
                    if (jsonObject.containsKey("return_code")) {
                        switch (jsonObject.getString("return_code")) {
                            case "FAIL":
                                Toast.makeText(MainActivity.this, jsonObject.getString("error_msg"), Toast.LENGTH_SHORT).show();
                                break;
                            case "SUCCESS":
                                if (HeebitApi.hasInstalled(MainActivity.this, "com.hynet.heebit")) {
                                    HeebitApi.doPayment(MainActivity.this, JSONObject.parseObject(msg.obj.toString()).getString("hy_pay_id"));
                                } else {
                                    Toast.makeText(MainActivity.this, "请检查是否安装CKPay", Toast.LENGTH_SHORT).show();
                                }
                                break;
                        }
                    }
                    break;
                case REQUEST_FAIL:
                    Log.d("请求失败", msg.obj.toString());
                    Toast.makeText(MainActivity.this, msg.obj.toString(), Toast.LENGTH_SHORT).show();
                    break;
                case REQUEST_ERROR:
                    Log.d("请求异常", msg.obj.toString());
                    Toast.makeText(MainActivity.this, msg.obj.toString(), Toast.LENGTH_SHORT).show();
                    break;
                default:
                    break;
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tvCoinType = findViewById(R.id.tvCoinType);
        etAmount = findViewById(R.id.etAmount);
        findViewById(R.id.llCoinType).setOnClickListener(this);
        findViewById(R.id.btnPayment).setOnClickListener(this);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode) {
            case Constant.RequestCode.SDK_PAYMENT:
                switch (resultCode) {
                    case Constant.ResultCode.SDK_PAYMENT:
                        Toast.makeText(this, "result_code:" + data.getStringExtra("result_code") + " ," + "result_message:" + data.getStringExtra("result_message"), Toast.LENGTH_SHORT).show();
                        break;
                    default:
                        break;
                }
                break;
            case 1:
                switch (resultCode) {
                    case 1:
                        tvCoinType.setText(data.getStringExtra("coin_code"));
                        break;
                    default:
                        break;
                }
                break;
            default:
                break;

        }
    }

    private void intialize() {
        timestamp = new SimpleDateFormat("yyyyMMddHHmmss", Locale.getDefault()).format(new Date(System.currentTimeMillis()));
        final JSONObject requestParams = new JSONObject();
        requestParams.put("app_id", app_id);
        JSONObject biz_content = new JSONObject();
        biz_content.put("out_trade_no", UUID.randomUUID().toString().replace("-", "").toUpperCase());
        biz_content.put("coin_code", tvCoinType.getText());
        biz_content.put("subject", subject);
        biz_content.put("trade_currency", trade_currency);
        biz_content.put("total_fee", etAmount.getText().toString());
        biz_content.put("over_market_rate", over_market_rate);
        biz_content.put("client_ip", client_ip);
        biz_content.put("notify_url", notify_url);
        biz_content.put("return_url", return_url);
        requestParams.put("biz_content", biz_content.toString());
        requestParams.put("charset", charset);
        requestParams.put("mch_id", mch_id);
        requestParams.put("method", method);
        requestParams.put("sign_type", sign_type);
        requestParams.put("timestamp", timestamp);
        requestParams.put("version", version);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("app_id").append("=").append(app_id).append("&")
                .append("biz_content").append("=").append(biz_content.toString()).append("&")
                .append("charset").append("=").append(charset).append("&")
                .append("mch_id").append("=").append(mch_id).append("&")
                .append("method").append("=").append(method).append("&")
                .append("sign_type").append("=").append(sign_type).append("&")
                .append("timestamp").append("=").append(timestamp).append("&")
                .append("version").append("=").append(version).append("&")
                .append("key").append("=").append(key);
        requestParams.put("sign", HttpUtil.md5(stringBuilder.toString()));
        Executors.newScheduledThreadPool(1).execute(new Runnable() {

            @Override
            public void run() {
                HttpUtil.doPost(requestParams, "https://local.heepay.com/Heebit/api/v1/PayApply", handler, REQUEST_SUCCESS, REQUEST_FAIL, REQUEST_ERROR);
            }
        });
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.llCoinType:
                Intent intent = new Intent();
                intent.setClass(this, CoinListActivity.class);
                startActivityForResult(intent, 1);
                break;
            case R.id.btnPayment:
                intialize();
                break;
            default:
                break;
        }
    }
}
