package com.hynet.heebit.sdk.demo;

import android.os.Handler;
import android.text.TextUtils;

import com.alibaba.fastjson.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.security.MessageDigest;

public class HttpUtil {

    private HttpUtil() {
        // cannot be instantiated
    }

    public static synchronized void doPost(JSONObject jsonObject, String url, Handler handler, int... message) {
        if (!TextUtils.isEmpty(jsonObject.toString())) {
            BufferedReader bufferedReader = null;
            try {
                HttpURLConnection httpURLConnection = (HttpURLConnection) new URL(url).openConnection();
                httpURLConnection.setRequestMethod("POST");
                httpURLConnection.setDoOutput(true);
                httpURLConnection.setDoInput(true);
                httpURLConnection.setUseCaches(false);
                httpURLConnection.setRequestProperty("Connection", "Keep-Alive");
                httpURLConnection.setRequestProperty("Charset", "UTF-8");
                httpURLConnection.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
                httpURLConnection.setRequestProperty("accept", "application/json");
                httpURLConnection.setRequestProperty("Content-Length", String.valueOf(jsonObject.toJSONString().getBytes().length));
                OutputStream outwritestream = httpURLConnection.getOutputStream();
                outwritestream.write(jsonObject.toJSONString().getBytes());
                outwritestream.flush();
                outwritestream.close();
                if (httpURLConnection.getResponseCode() == 200) {
                    bufferedReader = new BufferedReader(new InputStreamReader(httpURLConnection.getInputStream()));
                    handler.sendMessage(MessageUtil.getInstance().getMessage(message[0], bufferedReader.readLine()));
                } else {
                    handler.sendMessage(MessageUtil.getInstance().getMessage(message[1], "网络请求失败"));
                }
            } catch (ProtocolException e) {
                e.printStackTrace();
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                if (bufferedReader != null) {
                    try {
                        bufferedReader.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        } else {
            handler.sendMessage(MessageUtil.getInstance().getMessage(message[1], "请求参数为空"));
        }
    }

    public static final String md5(String data) {
        char hexDigits[] = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F'};
        try {
            MessageDigest messageDigest = MessageDigest.getInstance("MD5");
            messageDigest.update(data.getBytes());
            byte[] md = messageDigest.digest();
            int j = md.length;
            char chars[] = new char[j * 2];
            int k = 0;
            for (int i = 0; i < j; i++) {
                byte byte0 = md[i];
                chars[k++] = hexDigits[byte0 >>> 4 & 0xf];
                chars[k++] = hexDigits[byte0 & 0xf];
            }
            return String.valueOf(chars);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}

